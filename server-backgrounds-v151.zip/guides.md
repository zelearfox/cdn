 __       __                                                        _______   _______              ______  
|  \     /  \                                                      |       \ |       \            /      \ 
| $$\   /  $$  ______    _______   _______   ______   __   __   __ | $$$$$$$\| $$$$$$$\  ______  |  $$$$$$\
| $$$\ /  $$$ /      \  /       \ /       \ /      \ |  \ |  \ |  \| $$  | $$| $$  | $$ /      \ | $$___\$$
| $$$$\  $$$$|  $$$$$$\|  $$$$$$$|  $$$$$$$|  $$$$$$\| $$ | $$ | $$| $$  | $$| $$  | $$|  $$$$$$\ \$$    \ 
| $$\$$ $$ $$| $$  | $$ \$$    \ | $$      | $$  | $$| $$ | $$ | $$| $$  | $$| $$  | $$| $$  | $$ _\$$$$$$\
| $$ \$$$| $$| $$__/ $$ _\$$$$$$\| $$_____ | $$__/ $$| $$_/ $$_/ $$| $$__/ $$| $$__/ $$| $$__/ $$|  \__| $$
| $$  \$ | $$ \$$    $$|       $$ \$$     \ \$$    $$ \$$   $$   $$| $$    $$| $$    $$ \$$    $$ \$$    $$
 \$$      \$$  \$$$$$$  \$$$$$$$   \$$$$$$$  \$$$$$$   \$$$$$\$$$$  \$$$$$$$  \$$$$$$$   \$$$$$$   \$$$$$$ 


---

🔥 This addon for Pterodactyl was purchased using carding just to spite the developers! 🔥
💸 I did not lose a single penny – suck it! 💸

🚀 Этот аддон для Pterodactyl был приобретен с использованием кардинга назло разработчикам! 🚀
💰 Я совсем ничего не потерял – сосите! 💰

---

# Guide
To get started ensure you have Pterodactyl Installed & Blueprint Framework!

## Installation Steps
- Download the zip from BuiltByIt/SourceExchange.
- Extract the Zip Files.
- Transfer the *.blueprint file to your VM or Server.
- Navigate to your Pterodactyl Directory usually: `/var/www/pterodactyl`
- Move the *.blueprint file to that directory Example: `mv /home/username/Downloads/*.blueprint /var/www/pterodactyl`
- Run `blueprint -install *.blueprint`
- Follow Install Steps.