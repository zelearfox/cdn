                       
Navigate to /var/www/pterodactyl/resources/views/layouts
Find line 113, It should be the </li> of Navigation Entry:

<li class="{{ ! starts_with(Route::currentRouteName(), 'admin.users') ?: 'active' }}">
    <a href="{{ route('admin.users') }}">
        <i class="fa fa-users"></i> <span>Users</span>
    </a>
</li> -- Line 113 should be This

Add this Below:
<li class="{{ Route::currentRouteName() == 'admin.laravel-logs.laravel' ? 'active' : '' }}">
    <a href="{{ route('admin.laravel-logs.laravel') }}">
        <i class="fa fa-file-text-o"></i> <span>System Logs</span>
    </a>
</li>

Navigate to /var/www/pterodactyl/routes/admin.php,
Go to the ned of the document and add this code:

/*
|--------------------------------------------------------------------------
| Laravel Logs Controller Routes [Euphoria Development]
|--------------------------------------------------------------------------
|
| Endpoint: /admin/laravel-logs
|
*/
Route::group(['prefix' => 'laravel-logs'], function () {
    Route::get('/', [Admin\LaravelController::class, 'showLogs'])->name('admin.laravel-logs.laravel');
    Route::get('/download', [Admin\LaravelController::class, 'downloadLogs'])->name('admin.laravel-logs.download');
});

Navigate to /var/www/pterodactyl/app/Http/Controllers/Admin,
Add the LaravelController.php file to the Directory

Navigate to /var/www/pterodactyl/resources/views/admin,
Add the laravel-logs folder and content to the Directory.